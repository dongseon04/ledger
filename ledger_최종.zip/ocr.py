from flask import Flask, request, jsonify, render_template, redirect, url_for, flash, session
from PIL import Image, UnidentifiedImageError
import pytesseract, requests, re
from datetime import datetime, timedelta, date as _date

# DB / 로그인
from flask_sqlalchemy import SQLAlchemy
from flask_login import (
    LoginManager, UserMixin, login_user, logout_user,
    login_required, current_user
)
from werkzeug.security import generate_password_hash, check_password_hash
from sqlalchemy.sql import func

# ---- Tesseract 경로 (Windows 예시) ----
pytesseract.pytesseract.tesseract_cmd = r"C:\\Program Files\\Tesseract-OCR\\tesseract.exe"

# 🔧 templates/static 경로를 명시적으로 지정
app = Flask(__name__, template_folder="templates", static_folder="static")

# ---- Flask & DB 설정 ----
app.config["SECRET_KEY"] = "dev-secret"
app.config["SQLALCHEMY_DATABASE_URI"] = "mysql+pymysql://root:wsuser!@127.0.0.1:3336/ledger?charset=utf8mb4"
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

# 세션(자동 로그인 방지)
app.config["SESSION_PERMANENT"] = False
app.config["PERMANENT_SESSION_LIFETIME"] = timedelta(minutes=30)
app.config["SESSION_COOKIE_HTTPONLY"] = True
app.config["SESSION_COOKIE_SAMESITE"] = "Lax"

db = SQLAlchemy(app)
login_manager = LoginManager(app)
login_manager.login_view = "login"

# ✅ next 파라미터 없이 /login 으로만 보내기
@login_manager.unauthorized_handler
def _unauthorized():
    return redirect(url_for('login'))

# ✅ 템플릿에서 {{ now().year }} 사용 가능
@app.context_processor
def inject_now():
    return {"now": datetime.now}

# =======================
#        MODELS
# =======================
class Member(UserMixin, db.Model):
    __tablename__ = "members"
    idx       = db.Column(db.Integer, primary_key=True, autoincrement=True)
    username  = db.Column(db.String(50), nullable=False)
    userid    = db.Column(db.String(50), nullable=False, unique=True)
    userpw    = db.Column(db.String(255), nullable=False)
    useremail = db.Column(db.String(255), nullable=False, default="")
    userphone = db.Column(db.String(20),  nullable=False, default="")
    regdate   = db.Column(db.DateTime(timezone=True), server_default=func.now(), nullable=False)
    def get_id(self): return str(self.idx)

class Category(db.Model):
    __tablename__ = "categories"
    id      = db.Column(db.SmallInteger, primary_key=True, autoincrement=True)
    code    = db.Column(db.String(32), unique=True, nullable=False)
    name_ko = db.Column(db.String(50), nullable=False)

class Receipt(db.Model):
    __tablename__ = "receipts"
    id           = db.Column(db.Integer, primary_key=True, autoincrement=True)
    user_id      = db.Column(db.Integer, db.ForeignKey("members.idx", ondelete="CASCADE", onupdate="CASCADE"), nullable=False)
    category_id  = db.Column(db.SmallInteger, db.ForeignKey("categories.id", ondelete="SET NULL", onupdate="CASCADE"), nullable=True)
    file_name    = db.Column(db.String(255))
    raw_text     = db.Column(db.Text)
    summary_date = db.Column(db.DateTime)
    created_at   = db.Column(db.DateTime, server_default=func.now())
    category     = db.relationship("Category", lazy="joined")

class ReceiptItem(db.Model):
    __tablename__ = "receipt_items"
    id         = db.Column(db.Integer, primary_key=True, autoincrement=True)
    receipt_id = db.Column(db.Integer, db.ForeignKey("receipts.id", ondelete="CASCADE", onupdate="CASCADE"), nullable=False)
    menu_name  = db.Column(db.String(255))
    price      = db.Column(db.Integer)

class Income(db.Model):
    __tablename__ = "incomes"
    id         = db.Column(db.Integer, primary_key=True, autoincrement=True)
    user_id    = db.Column(db.Integer, nullable=False)
    amount     = db.Column(db.Integer, nullable=False)
    memo       = db.Column(db.String(255))
    date       = db.Column(db.Date, nullable=False)
    created_at = db.Column(db.DateTime, server_default=func.now())

@login_manager.user_loader
def load_user(user_id):
    return Member.query.get(int(user_id))

# ---- 초기 테이블 생성 + 기본 카테고리 시드 ----
def seed_categories_if_needed():
    defaults = [
        ("FOOD", "식비"),
        ("HOUSING_COMM", "주거/통신"),
        ("TRANSPORT", "교통/이동"),
        ("SHOPPING", "쇼핑/구매"),
        ("EDU", "교육/자기계발"),
        ("HEALTH", "건강/의료"),
        ("LEISURE", "취미/여가"),
        ("FINANCE", "금융/저축"),
        ("OTHER", "기타"),
    ]
    if Category.query.count() == 0:
        for code, name in defaults:
            db.session.add(Category(code=code, name_ko=name))
        db.session.commit()

with app.app_context():
    db.create_all()
    try:
        seed_categories_if_needed()
    except Exception as e:
        print("Seed categories error:", e)

@app.before_request
def _no_permanent_session():
    session.permanent = False

# =======================
#        ROUTES (UI)
# =======================
@app.route("/", methods=["GET"])
@login_required
def home():
    return render_template("dashboard.html")

@app.route("/upload", methods=["GET"])
@login_required
def upload():
    # 간단 업로드 화면이 따로 있다면 templates/index.html로 렌더
    return render_template("index.html")

# =======================
#   CATEGORY / RECEIPT APIs
# =======================
@app.route("/api/categories", methods=["GET"])
@login_required
def api_categories():
    rows = Category.query.order_by(Category.id.asc()).all()
    return jsonify([{"id": c.id, "code": c.code, "name": c.name_ko} for c in rows])

@app.route("/api/receipts", methods=["GET"])
@login_required
def api_receipts():
    q = (
        Receipt.query
        .filter_by(user_id=current_user.idx)
        .order_by(Receipt.created_at.desc())
        .limit(100)
    )
    receipts = q.all()
    rid_list = [r.id for r in receipts]
    items_by_rid = {rid: [] for rid in rid_list}
    if rid_list:
        for it in ReceiptItem.query.filter(ReceiptItem.receipt_id.in_(rid_list)).all():
            items_by_rid[it.receipt_id].append({
                "id": it.id,
                "name": it.menu_name,
                "price": it.price or 0
            })

    data = []
    for r in receipts:
        shown_dt = r.summary_date or r.created_at
        data.append({
            "id": r.id,
            "date": shown_dt.strftime("%Y-%m-%d %H:%M") if shown_dt else "",
            "file_name": r.file_name or "",
            "category": ({
                "id": r.category.id,
                "code": r.category.code,
                "name": r.category.name_ko
            } if r.category else None),
            "items": items_by_rid.get(r.id, [])
        })
    return jsonify(data)

@app.route("/api/receipts/<int:rid>/category", methods=["PUT", "PATCH"])
@login_required
def api_set_receipt_category(rid):
    r = Receipt.query.filter_by(id=rid, user_id=current_user.idx).first()
    if not r:
        return jsonify({"error": "not found"}), 404

    payload = request.get_json(silent=True) or {}
    cat_id = payload.get("category_id")
    cat_code = (payload.get("category_code") or "").strip().upper()

    cat = None
    if cat_id is not None:
        cat = Category.query.filter_by(id=cat_id).first()
    elif cat_code:
        cat = Category.query.filter_by(code=cat_code).first()

    if payload and (cat_id is None and not cat_code):
        return jsonify({"error": "category_id 또는 category_code를 보내주세요."}), 400

    if payload and (cat_id is not None or cat_code):
        if not cat:
            return jsonify({"error": "invalid category"}), 400
        r.category_id = cat.id
    else:
        r.category_id = None

    db.session.commit()

    return jsonify({
        "ok": True,
        "receipt_id": r.id,
        "category": ({
            "id": r.category.id,
            "code": r.category.code,
            "name": r.category.name_ko
        } if r.category else None)
    })

# =======================
#        AUTH
# =======================
@app.route("/signup", methods=["GET", "POST"])
def signup():
    if request.method == "POST":
        userid   = (request.form.get("userid") or "").strip()
        password = (request.form.get("password") or "").strip()
        username = (request.form.get("username") or "").strip()
        email    = (request.form.get("email") or "").strip()
        phone    = (request.form.get("phone") or "").strip()

        if not (userid and password and username):
            flash("아이디/비밀번호/이름은 필수입니다.", "danger")
            return redirect(url_for("signup"))

        if Member.query.filter_by(userid=userid).first():
            flash("이미 존재하는 아이디입니다.", "warning")
            return redirect(url_for("signup"))

        m = Member(
            userid=userid,
            userpw=generate_password_hash(password),
            username=username,
            useremail=email,
            userphone=phone,
        )
        db.session.add(m); db.session.commit()
        flash("가입 완료! 로그인 해주세요.", "success")
        return redirect(url_for("login"))

    if current_user.is_authenticated:
        return redirect(url_for("home"))
    return render_template("signup.html")

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        userid = request.form.get("userid")
        password = request.form.get("password")
        m = Member.query.filter_by(userid=userid).first()

        if not m or not check_password_hash(m.userpw, password):
            flash("아이디 또는 비밀번호가 올바르지 않습니다.", "danger")
            return redirect(url_for("login"))

        login_user(m, remember=False)
        return redirect(url_for("home"))

    if current_user.is_authenticated:
        return redirect(url_for("home"))
    return render_template("login.html")

@app.route("/logout")
@login_required
def logout():
    logout_user()
    session.clear()
    flash("로그아웃 되었습니다.", "success")
    return redirect(url_for("login"))

# =======================
#    UTIL: 요약 파싱
# =======================
def parse_summary(summary_text: str):
    if not summary_text:
        return None, []

    dt = None
    m = re.search(r"날짜\s*[:：]\s*([0-9]{4}-[0-9]{2}-[0-9]{2})\s+([0-9]{2}:[0-9]{2})", summary_text)
    if m:
        try:
            dt = datetime.strptime(f"{m.group(1)} {m.group(2)}", "%Y-%m-%d %H:%M")
        except Exception:
            dt = None

    items, started = [], False
    for ln in (l.strip() for l in summary_text.splitlines() if l.strip()):
        if ln.startswith("- 메뉴"):
            started = True
            continue
        if not started or not ln.startswith("-") or ":" not in ln:
            continue
        left, right = ln.split(":", 1)
        name = left.lstrip("-* ").strip()
        digits = re.sub(r"[^\d]", "", right)
        if not name or not digits:
            continue
        try:
            price = int(digits)
        except ValueError:
            continue
        items.append({"name": name, "price": price})
    return dt, items

# =======================
#   OCR + 요약 + 저장
# =======================
@app.route("/process", methods=["POST"])
@login_required
def process_receipt():
    if "file" not in request.files:
        return jsonify({"error": "파일이 전송되지 않았습니다."}), 400

    file = request.files["file"]
    raw_cat_id = (request.form.get("category_id") or "").strip()
    raw_cat_code = (request.form.get("category_code") or "").strip().upper()

    try:
        original_name = file.filename or ""
        image = Image.open(file.stream)
        ocr_text = pytesseract.image_to_string(image, lang="kor+eng").strip()
        if not ocr_text:
            return jsonify({"error": "OCR 결과가 없습니다. 이미지 상태를 확인하세요."}), 400

        qwen_api_url = "http://localhost:11434/api/chat"
        qwen_payload = {
            "model": "mistral",
            "stream": False,
            "messages": [{
                "role": "user",
                "content": (
                    f"다음은 영수증 OCR 텍스트입니다.\n\n{ocr_text}\n\n"
                    "아래 규칙으로 반드시 요약:\n"
                    "1) '**요약**'으로 시작할 것.\n"
                    "2) 날짜는 YYYY-MM-DD HH:mm 형식.\n"
                    "3) 메뉴는 반드시 '- 메뉴:' 아래에 '- 메뉴명: 금액' 형식으로 출력.\n"
                    "불필요한 설명 금지.\n"
                    "예시:\n"
                    "**요약**\n- 날짜: 2024-09-12 18:59\n- 메뉴:\n- 크림 파스타: 15000원\n- 닭 한 마리 쌀국수: 7000원"
                )
            }]
        }
        res = requests.post(qwen_api_url, json=qwen_payload, timeout=60)
        res.encoding = "utf-8"
        if res.status_code != 200:
            return jsonify({"error": "Qwen API 호출 실패", "status": res.status_code}), 500

        qwen_content = (res.json().get("message", {}) or {}).get("content", "") or ""
        if not qwen_content.strip():
            qwen_content = "**요약**\n- 날짜: 없음\n- 메뉴:\n- 메뉴 없음: 0"

        summary_date, items = parse_summary(qwen_content)

        category = None
        if raw_cat_id.isdigit():
            category = Category.query.filter_by(id=int(raw_cat_id)).first()
        elif raw_cat_code:
            category = Category.query.filter_by(code=raw_cat_code).first()

        new_receipt = Receipt(
            user_id=current_user.idx,
            file_name=original_name,
            raw_text=ocr_text,
            summary_date=summary_date,
            category_id=(category.id if category else None)
        )
        db.session.add(new_receipt)
        db.session.flush()

        if items:
            db.session.bulk_insert_mappings(
                ReceiptItem,
                [{"receipt_id": new_receipt.id, "menu_name": it["name"], "price": it["price"]}
                 for it in items]
            )

        db.session.commit()

        return jsonify({
            "receipt_id": new_receipt.id,
            "user_id": current_user.idx,
            "raw_text": ocr_text,
            "processed_text": qwen_content,
            "parsed": {
                "summary_date": summary_date.strftime("%Y-%m-%d %H:%M") if summary_date else None,
                "items": items
            },
            "category": ({
                "id": category.id,
                "code": category.code,
                "name": category.name_ko
            } if category else None)
        })

    except UnidentifiedImageError:
        db.session.rollback()
        return jsonify({"error": "이미지 파일이 아닙니다."}), 400
    except requests.exceptions.Timeout:
        db.session.rollback()
        return jsonify({"error": "Qwen API 요청이 시간 초과되었습니다."}), 504
    except Exception as e:
        db.session.rollback()
        print("서버 오류:", e)
        return jsonify({"error": str(e)}), 500

# =======================
#   지출 수정/삭제 API
# =======================
@app.route("/api/receipts/<int:rid>", methods=["DELETE"])
@login_required
def api_delete_receipt(rid):
    r = Receipt.query.filter_by(id=rid, user_id=current_user.idx).first()
    if not r:
        return jsonify({"error":"not found"}), 404
    db.session.delete(r)
    db.session.commit()
    return jsonify({"ok": True})

@app.route("/api/receipts/<int:rid>", methods=["PUT"])
@login_required
def api_update_receipt(rid):
    """지출의 파일명과 항목을 갱신"""
    r = Receipt.query.filter_by(id=rid, user_id=current_user.idx).first()
    if not r:
        return jsonify({"error":"not found"}), 404

    data = request.get_json(silent=True) or {}
    items = data.get("items", [])

    try:
        # ✅ 파일명 갱신 (여러 키 허용)
        if "file_name" in data or "filename" in data or "fileName" in data:
            new_name = (data.get("file_name")
                        or data.get("filename")
                        or data.get("fileName") or "").strip()
            r.file_name = new_name

        # ✅ 항목 전체 교체
        ReceiptItem.query.filter_by(receipt_id=rid).delete()
        if items:
            db.session.bulk_insert_mappings(
                ReceiptItem,
                [{
                    "receipt_id": rid,
                    "menu_name": (it.get("name") or "").strip(),
                    "price": int(it.get("price") or 0)
                } for it in items if (it.get("name") or "").strip()]
            )

        db.session.commit()
        return jsonify({"ok": True, "id": r.id, "file_name": r.file_name})
    except Exception as e:
        db.session.rollback()
        return jsonify({"error": str(e)}), 500


# =======================
#      INCOME APIs
# =======================
def _parse_yyyymmdd(s: str):
    try:
        return datetime.strptime(s, "%Y-%m-%d").date()
    except Exception:
        return None

@app.route("/api/incomes", methods=["GET"])
@login_required
def api_incomes():
    rows = (
        Income.query
        .filter_by(user_id=current_user.idx)
        .order_by(Income.date.desc(), Income.id.desc())
        .all()
    )
    data = [{
        "id": r.id,
        "date": r.date.strftime("%Y-%m-%d"),
        "amount": int(r.amount or 0),
        "memo": r.memo or ""
    } for r in rows]
    return jsonify(data)

@app.route("/api/incomes", methods=["POST"])
@login_required
def api_income_create():
    data = request.get_json(silent=True) or {}
    amount = int(data.get("amount") or 0)
    memo   = (data.get("memo") or "").strip()
    dstr   = (data.get("date") or "").strip()

    if amount <= 0:
        return jsonify({"error": "amount must be positive"}), 400

    d = _parse_yyyymmdd(dstr) or _date.today()

    row = Income(user_id=current_user.idx, amount=amount, memo=memo, date=d)
    db.session.add(row)
    db.session.commit()
    return jsonify({"ok": True, "id": row.id})

@app.route("/api/incomes/<int:iid>", methods=["DELETE"])
@login_required
def api_income_delete(iid):
    row = Income.query.filter_by(id=iid, user_id=current_user.idx).first()
    if not row:
        return jsonify({"error":"not found"}), 404
    db.session.delete(row)
    db.session.commit()
    return jsonify({"ok": True})

# (선택) 헬스체크
@app.route("/ping")
def ping():
    return "pong"

# =======================
#        MAIN
# =======================
if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=True)