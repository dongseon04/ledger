from flask import Flask, request, jsonify, render_template, redirect, url_for, flash, session
from PIL import Image, UnidentifiedImageError
import pytesseract, requests, os
from datetime import datetime, timedelta

# ==== DB/로그인 ====
from flask_sqlalchemy import SQLAlchemy
from flask_login import (
    LoginManager, UserMixin, login_user, logout_user,
    login_required, current_user
)
from werkzeug.security import generate_password_hash, check_password_hash
from sqlalchemy.sql import func

# Tesseract 실행 파일 경로
pytesseract.pytesseract.tesseract_cmd = r"C:\\Program Files\\Tesseract-OCR\\tesseract.exe"

app = Flask(__name__)

# ==== Flask & DB 설정 (db 초기화보다 위!) ====
app.config["SECRET_KEY"] = "dev-secret"  # 배포 시 환경변수로 교체 권장
app.config["SQLALCHEMY_DATABASE_URI"] = "mysql+pymysql://root:root1234@127.0.0.1:3306/ledger?charset=utf8mb4"
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

# 세션/쿠키 보안 & 만료 (자동로그인 방지)
app.config["SESSION_PERMANENT"] = False              # 브라우저 닫으면 세션 소멸
app.config["PERMANENT_SESSION_LIFETIME"] = timedelta(minutes=30)  # (옵션) 최대 30분
app.config["SESSION_COOKIE_HTTPONLY"] = True
app.config["SESSION_COOKIE_SAMESITE"] = "Lax"

db = SQLAlchemy(app)
login_manager = LoginManager(app)
login_manager.login_view = "login"

# ===== 모델 =====
class Member(UserMixin, db.Model):
    __tablename__ = "members"
    idx       = db.Column(db.Integer, primary_key=True, autoincrement=True)
    username  = db.Column(db.String(50), nullable=False)
    userid    = db.Column(db.String(50), nullable=False, unique=True)
    userpw    = db.Column(db.String(255), nullable=False)  # 해시 저장
    useremail = db.Column(db.String(255))
    userphone = db.Column(db.String(20))
    regdate   = db.Column(db.DateTime(timezone=True), server_default=func.now(), nullable=False)
    def get_id(self): return str(self.idx)

@login_manager.user_loader
def load_user(user_id):
    return Member.query.get(int(user_id))

with app.app_context():
    db.create_all()  # members 테이블이 이미 있으면 그대로 둠

# 모든 요청에서 세션을 비영구로 유지(브라우저 닫으면 만료)
@app.before_request
def _no_permanent_session():
    session.permanent = False

# ===== 라우트 =====
@app.route("/", methods=["GET"])
def home():
    # 로그인 안 했으면 로그인 페이지로
    if not current_user.is_authenticated:
        return redirect(url_for("login"))
    return render_template("index.html")  # 간편장부 페이지(업로드 폼)

# --- 회원가입 ---
@app.route("/signup", methods=["GET", "POST"])
def signup():
    if request.method == "POST":
        userid   = request.form.get("userid")
        password = request.form.get("password")
        username = request.form.get("username")
        email    = request.form.get("email")
        phone    = request.form.get("phone")

        if not (userid and password and username):
            flash("아이디/비밀번호/이름은 필수입니다.", "danger")
            return redirect(url_for("signup"))

        if Member.query.filter_by(userid=userid).first():
            flash("이미 존재하는 아이디입니다.", "warning")
            return redirect(url_for("signup"))

        m = Member(
            userid=userid,
            userpw=generate_password_hash(password),
            username=username,
            useremail=email or None,
            userphone=phone or None,
        )
        db.session.add(m); db.session.commit()
        flash("가입 완료! 로그인 해주세요.", "success")
        return redirect(url_for("login"))
    # 이미 로그인했다면 홈으로
    if current_user.is_authenticated:
        return redirect(url_for("home"))
    return render_template("signup.html")

# --- 로그인/로그아웃 ---
@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        userid = request.form.get("userid")
        password = request.form.get("password")
        m = Member.query.filter_by(userid=userid).first()

        if not m or not check_password_hash(m.userpw, password):
            flash("아이디 또는 비밀번호가 올바르지 않습니다.", "danger")
            return redirect(url_for("login"))

        # remember=False → 별도 영구 쿠키 미발급 (브라우저 닫으면 세션 소멸)
        login_user(m, remember=False)
        return redirect(url_for("home"))

    if current_user.is_authenticated:
        return redirect(url_for("home"))
    return render_template("login.html")

@app.route("/logout")
@login_required
def logout():
    logout_user()      # Flask-Login 세션 종료
    session.clear()    # 세션 키/값 전체 삭제(보수적)
    flash("로그아웃 되었습니다.", "success")
    return redirect(url_for("login"))

# --- OCR + Qwen (로그인 필요) ---
@app.route("/process", methods=["POST"])
@login_required
def process_receipt():
    if "file" not in request.files:
        return jsonify({"error": "파일이 전송되지 않았습니다."}), 400

    file = request.files["file"]

    try:
        image = Image.open(file.stream)
        # 한국어+영어 혼용 영수증이면 'kor+eng' 이 더 정확
        ocr_text = pytesseract.image_to_string(image, lang="kor+eng").strip()
        if not ocr_text:
            return jsonify({"error": "OCR 결과가 없습니다. 이미지 상태를 확인하세요."}), 400

        qwen_api_url = "http://localhost:11434/api/chat"
        qwen_payload = {
            "model": "mistral",
            "stream": False,
            "messages": [{
                "role": "user",
                "content": (
                    f"다음은 영수증 OCR 텍스트입니다.\n\n{ocr_text}\n\n"
                    "아래 규칙으로 반드시 요약:\n"
                    "1) '**요약**'으로 시작할 것.\n"
                    "2) 날짜는 YYYY-MM-DD HH:mm 형식.\n"
                    "3) 메뉴는 반드시 '- 메뉴:' 아래에 '- 메뉴명: 금액' 형식으로 출력.\n"
                    "불필요한 설명 금지.\n"
                    "예시:\n"
                    "**요약**\n- 날짜: 2024-09-12 18:59\n- 메뉴:\n- 크림 파스타: 15000원\n- 닭 한 마리 쌀국수: 7000원"
                )
            }]
        }

        res = requests.post(qwen_api_url, json=qwen_payload, timeout=60)
        res.encoding = "utf-8"
        if res.status_code != 200:
            return jsonify({"error": "Qwen API 호출 실패", "status": res.status_code}), 500

        qwen_content = (res.json().get("message", {}) or {}).get("content", "") or ""
        if "**요약**" not in qwen_content:
            qwen_content = "**요약**\n- 날짜: 없음\n- 메뉴:\n- 메뉴 없음: 0"

        return jsonify({"raw_text": ocr_text, "processed_text": qwen_content})

    except UnidentifiedImageError:
        return jsonify({"error": "이미지 파일이 아닙니다."}), 400
    except requests.exceptions.Timeout:
        return jsonify({"error": "Qwen API 요청이 시간 초과되었습니다."}), 504
    except Exception as e:
        print("서버 오류:", e)
        return jsonify({"error": str(e)}), 500

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=True)
